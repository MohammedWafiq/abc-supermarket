<?php
session_start();

// Check if the user has confirmed logout
if (isset($_POST['confirm_logout']) && $_POST['confirm_logout'] === 'yes') {
    // Destroy the session and redirect to login page
    session_destroy();
    header("Location: login.php");
    exit();
}

// If not confirmed, show the confirmation form
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Confirm Logout</title>
    <link rel="stylesheet" href="logout.css">
</head>
<body>
    <div class="container">
        <h1>Are you sure you want to log out?</h1>
        <form method="post">
            <input type="hidden" name="confirm_logout" value="yes">
            <button type="submit" class="btn btn-primary">Yes, log me out</button>
            <a href="index.php" class="btn btn-secondary">Cancel</a>
        </form>
    </div>
</body>
</html>

<?php
include('db.php');
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

include('header.php'); // Include the navigation bar

$sql = "SELECT * FROM products";
$result = $conn->query($sql);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $product_id = $_POST['product_id'];
    $quantity = $_POST['quantity'];
    $user_id = $_SESSION['user_id'];

    $sql = "INSERT INTO cart (user_id, product_id, quantity) VALUES ('$user_id', '$product_id', '$quantity')";

    if ($conn->query($sql) === TRUE) {
        echo "Added to cart!";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>

<img src="img/cover.bmp" class="cover" alt="">
<div class="container">
    
    <h1>Products</h1>
    <a href="add_product.php" class="btn">Add New Product</a>
    <div class="grid">
        <?php while($row = $result->fetch_assoc()): ?>
            <div class="product">
                <img src="/uploads/<?php echo htmlspecialchars($row['image']); ?>" alt="<?php echo htmlspecialchars($row['name']); ?>">
                <h2><?php echo htmlspecialchars($row['name']); ?></h2>
                <p>AED <?php echo htmlspecialchars($row['price']); ?></p>
                <form method="POST" action="">
                    <input type="hidden" name="product_id" value="<?php echo htmlspecialchars($row['id']); ?>">
                    Quantity: <input type="number" name="quantity" value="1">
                    <button type="submit">Add to Cart</button>
                </form>
            </div>
        <?php endwhile; ?>
    </div>

</div>
<img src="img/bottomhome.png" class="cover" alt="">

<?php include('footer.php'); ?> <!-- Include the footer -->

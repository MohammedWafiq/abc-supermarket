<!-- footer.php -->
<footer>
    <div class="footer-container">
        <div class="footer-left">
            <h3>ABC Supermarket</h3>
            <p>Burjuman, Dubai, UAE</p>
            <p>Email: info@company.com</p>
            <p>Phone: (123) 456-7890</p>
        </div>
        <div class="footer-center">
            <h4>Quick Links</h4>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="products.php">Products</a></li>
                <li><a href="cart.php">Cart</a></li>
                <li><a href="checkout.php">Checkout</a></li>
                <li><a href="contact.php">Contact Us</a></li>
            </ul>
        </div>
        <div class="footer-right">
            <h4>Follow Us</h4>
            <a href="#" class="social-icon">Facebook</a>
            <a href="#" class="social-icon">Twitter</a>
            <a href="#" class="social-icon">Instagram</a>
            <a href="#" class="social-icon">LinkedIn</a>
        </div>
    </div>
    <div class="footer-bottom">
        <p>&copy; ABC Supermarket. All rights reserved.</p>
    </div>
</footer>

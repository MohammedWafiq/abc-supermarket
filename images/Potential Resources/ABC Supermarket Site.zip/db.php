<?php
$servername = "localhost";
$username = "abc_supermarket";
$password = "abc_supermarket";
$dbname = "abc_supermarket";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>

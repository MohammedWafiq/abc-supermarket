<?php
include('db.php');
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

include('header.php'); // Include the navigation bar

$user_id = $_SESSION['user_id'];

$sql = "
    SELECT products.id, products.name, products.price, cart.quantity 
    FROM cart 
    JOIN products ON cart.product_id = products.id 
    WHERE cart.user_id = '$user_id'
";
$result = $conn->query($sql);

$total = 0;

// Handle checkout
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $shipping_address = $_POST['shipping_address'];
    $sql = "INSERT INTO orders (user_id, total_price, shipping_address) VALUES ('$user_id', '$total', '$shipping_address')";
    
    if ($conn->query($sql) === TRUE) {
        $order_id = $conn->insert_id;
        
        // Move cart items to order_items
        $sql = "
            INSERT INTO order_items (order_id, product_id, quantity, price) 
            SELECT $order_id, product_id, quantity, price 
            FROM cart 
            JOIN products ON cart.product_id = products.id 
            WHERE user_id = '$user_id'
        ";
        $conn->query($sql);
        
        // Clear the cart
        $conn->query("DELETE FROM cart WHERE user_id = '$user_id'");
        
        echo "<script>
                alert('Order placed successfully! Your order ID is $order_id.');
                window.location.href = 'index.php';
              </script>";
        exit;
    } else {
        echo "<p>Error placing order: " . $conn->error . "</p>";
    }
}
?>

<div class="container">
    <h1>Checkout</h1>
    <?php if ($result->num_rows > 0): ?>
        <h3>Order Summary</h3>
        <table>
            <thead>
                <tr>
                    <th>Product</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody>
                <?php while($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $row['name']; ?></td>
                        <td>$<?php echo $row['price']; ?></td>
                        <td><?php echo $row['quantity']; ?></td>
                        <td>$<?php echo $row['price'] * $row['quantity']; ?></td>
                    </tr>
                    <?php $total += $row['price'] * $row['quantity']; ?>
                <?php endwhile; ?>
            </tbody>
        </table>
        <h3>Total: $<?php echo $total; ?></h3>

        <form method="POST" action="">
            <h3>Shipping Information</h3>
            <label for="shipping_address">Shipping Address:</label><br>
            <textarea name="shipping_address" id="shipping_address" rows="4" required></textarea><br><br>
            <button type="submit">Place Order</button>
        </form>
    <?php else: ?>
        <p>Your cart is empty.</p>
    <?php endif; ?>
</div>

<?php include('footer.php'); ?> <!-- Include the footer -->

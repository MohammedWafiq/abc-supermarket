<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Website</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <nav>
        <ul>
            <li class="logo-item"><a href="index.php" class="logo">ABC Supermarket</a></li>
            <li><a href="index.php" class="<?= ($_SERVER['PHP_SELF'] == '/index.php') ? 'active' : '' ?>">Home</a></li>
            <li><a href="cart.php" class="<?= ($_SERVER['PHP_SELF'] == '/cart.php') ? 'active' : '' ?>">Cart</a></li>
            <li><a href="checkout.php" class="<?= ($_SERVER['PHP_SELF'] == '/checkout.php') ? 'active' : '' ?>">Checkout</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </nav>
</body>
</html>
